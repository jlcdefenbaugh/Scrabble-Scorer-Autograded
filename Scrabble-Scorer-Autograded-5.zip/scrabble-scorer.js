// This assignment is inspired by a problem on Exercism (https://exercism.org/tracks/javascript/exercises/etl) that demonstrates Extract-Transform-Load using Scrabble's scoring system. 

const input = require("readline-sync");
let selectedWord = ''

const oldPointStructure = {
  1: ['A', 'E', 'I', 'O', 'U', 'L', 'N', 'R', 'S', 'T'],
  2: ['D', 'G'],
  3: ['B', 'C', 'M', 'P'],
  4: ['F', 'H', 'V', 'W', 'Y'],
  5: ['K'],
  8: ['J', 'X'],
  10: ['Q', 'Z']
};


function oldScrabbleScorer(word) {
	word = word.toUpperCase();
	let letterPoints = "";
 
	for (let i = 0; i < word.length; i++) {
 
	  for (const pointValue in oldPointStructure) {
 
		 if (oldPointStructure[pointValue].includes(word[i])) {
			letterPoints += `Points for '${word[i]}': ${pointValue}\n`
		 }
 
	  }
	}
	return letterPoints;
 }

// your job is to finish writing these functions and variables that we've named //
// don't change the names or your program won't work as expected. //

function initialPrompt() {
  console.log("Let's play some scrabble!");
  selectedWord = input.question("\nEnter a word to score: ")

  for(let i = 0; i < selectedWord.length; i++) {
  if(selectedWord[i].toLowerCase() === selectedWord[i].toUpperCase() && !selectedWord[i].includes(' ')) {
    selectedWord = input.question("Invalid input. Re-enter a word to score: ");
  }
}
  return selectedWord;
};



let simpleScore = function(word) {
  word = word.toLowerCase();
  let pointTotal = word.length;
  return pointTotal;
}


let vowelBonusScore = function(word) {
  word = word.toLowerCase();
  let vowel = 'aeiou'
  let pointTotal = 0;
  for(let i = 0; i < word.length; i++) {
    if(vowel.includes(word[i])) {
      pointTotal += 3;
    } else {
      pointTotal += 1;
    }
  }
  return pointTotal;
}


let newPointStructure = transform(oldPointStructure);
newPointStructure[' '] = 0;

let scrabbleScore = function(word, pointStructure) {
  word = word.toLowerCase();
  let pointTotal = 0;
  for(let i = 0; i < word.length; i++) {
    for(item in pointStructure) {
      if(item.includes(word[i])) {
        pointTotal += pointStructure[item]
      } 
    }
  }
  return pointTotal;
}


const scoringAlgorithms = [
  {
    name: 'Simple Score',
    description: 'Each letter is worth 1 point.',
    scoringFunction: simpleScore
  },
  {
    name: 'Bonus Vowels',
    description: 'Vowels are 3 pts, consonants are 1 pt.',
    scoringFunction: vowelBonusScore
  },
  {
    name: 'Scrabble',
    description: 'The traditional scoring algorithm.',
    scoringFunction: scrabbleScore
  },
];


  



function scorerPrompt() {
  let options = "\n0 - Simple: One point per character \n1 - Vowel Bonus: Vowels are worth 3 points \n2 - Scrabble: Uses scrabble point system";

  let selectedScorer = input.question(`Which scoring algorithm would you like to use?
${options}
Enter 0, 1, or 2: `);  
  
  while(Number(selectedScorer) > 2 || Number(selectedScorer) < 0 || isNaN(Number(selectedScorer))) {
    selectedScorer = input.question("Invalid input. Please enter 0, 1, or 2: ");
  }

    if(Number(selectedScorer) === 0) {
      console.log(`Score for '${selectedWord}': ${scoringAlgorithms[0].scoringFunction(selectedWord)}`);
    } else if(Number(selectedScorer) === 1) {
      console.log(`Score for '${selectedWord}': ${scoringAlgorithms[1].scoringFunction(selectedWord)}`);
    } else if(Number(selectedScorer) === 2) {
      console.log(`Score for '${selectedWord}': ${scoringAlgorithms[2].scoringFunction(selectedWord, newPointStructure)}`);
    }
  return selectedScorer;
}


function transform(oldObject) {
  let newObject = {}
  for(item in oldObject) {
    let letters = oldObject[item];
    for(let i = 0; i < letters.length; i++) {
      newObject[letters[i].toLowerCase()] = Number(item);
      if(letters === " ") {
        newObject[letters[i]] = 0;
      }
    }
  }
  return newObject;
}


function runProgram() {
   initialPrompt();
   scorerPrompt();
}

// Don't write any code below this line //
// And don't change these or your program will not run as expected //
module.exports = {
   initialPrompt: initialPrompt,
   transform: transform,
   oldPointStructure: oldPointStructure,
   simpleScore: simpleScore,
   vowelBonusScore: vowelBonusScore,
   scrabbleScore: scrabbleScore,
   scoringAlgorithms: scoringAlgorithms,
   newPointStructure: newPointStructure,
	runProgram: runProgram,
	scorerPrompt: scorerPrompt
};

